function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6YoMR9KzySO":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

